package com.example.yejin.baby_thermometer;
/**
 * 18.09.15 장 환석
 *Intent 안에는 번들 객체가 있는데, 번들 객체는 putExtra()와 get000Extra() 메소드로 데이터를 넣거나 빼낼 수 있다.
 * 이 때 넣을 수 있는 데이터는 바이트 배열이나 Serializable 객체도 가능하다.
 * 하지만 전달하고 싶은 데이터가 기본 자료형이 아니라 객체 데이터일 경우 객체의 데이터들을 바이트 배열로 변환하여 전달하거나
 * Serializable 인터페이스를 구현하는 객체를 만들어 직렬화한 후 전달할 수 있다.
 * 안드로이드에서는 Serializable과 비슷하지만 더 간편한 Parcelable을 사용한다.
 * 즉, 객체 데이터를 전달하기 위해서 Parcelable을 구현한다.
 */

import android.os.Parcel;
import android.os.Parcelable;
public class BabyData implements Parcelable {

    String name; //아기의 이름
    float temperature; //아기의 체온

    public BabyData (String name, float temp){
        //BabyData 객체의 정의
        name = name;
        temperature = temp;
    }

    public BabyData(Parcel src){
        //Parcel 객체에서 읽기
        name = src.readString();
        temperature = src.readFloat();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator(){
        /*
         * Parcel객체는 Bundle 객체(기본 자료형으 데이터를 전달할 때 사용하는 방식)처럼 readOOO()와 writeOOO 형태를
         * 가진 메소드를 제공하므로 기본 데이터 타입을 넣고 확인할 수 있다. 위 두 가지 형태의 메소드를 사용하기위해서는
         * CREATOR 상수를 정의해야 한다.
         */
        public BabyData createFromParcel(Parcel in){
            //BabyData 생성자를 호출해서 Parcel 객체에서 읽기
            return new BabyData(in);
        }

        public BabyData[] newArray(int size){
            return new BabyData[size];
        }
    };

    public int describeContents(){
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags){
        //객체가 가지고 있는 데이터를 Parcel 객체로 만들어 주는 역할을 한다.
        dest.writeString(name);
        dest.writeFloat(temperature);
    }
}
