package com.example.yejin.baby_thermometer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MeasureActivity extends AppCompatActivity {
    public static final int REQUEST_CODE_SETTING = 101;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_measure);
    }

    public void setCriteriaTemperature(View v){
        Intent intent = new Intent(getApplicationContext(), SettingActivity.class);
        /*
        getApplicationContext()? context 객체가 뭐지? page 265.
         */
        startActivityForResult(intent,REQUEST_CODE_SETTING );

        Toast.makeText(getApplicationContext(), "To Setting Activity!", Toast.LENGTH_LONG).show();
    }

    @Override
    //MeasureActivity class 안에 커서 두고 우클릭 - generate - override - onActivityResult
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        /*
         param1 : 액티비티를 띄울 때 전달했던 요청코드
         param2 : 응답을 보내 온 액티비티로부터 전달된 응답코드, 새로 띄운 액티비티에서 처리한 결과가 정상인지 아닌지를 구분하는데 사용.
         RESULT_OK는 처리 결과가 정상임을 의미
         param3 : 전달 받은 인텐트.
         */
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode ==REQUEST_CODE_SETTING){
            Toast.makeText(getApplicationContext(),
                    "onActivityResult 메소드 호출됨. 요청 코드 : " + requestCode + "결과 코드 : " + resultCode, Toast.LENGTH_LONG).show();
            if(resultCode == RESULT_OK){
                String name = data.getExtras().getString("name");
                Toast.makeText(getApplicationContext(), "응답으로 전달된 name : " + name,
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
